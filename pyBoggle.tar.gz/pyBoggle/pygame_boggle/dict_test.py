d = {}

my_set = set()

d[5] = my_set

print(d)

x = 6

my_set.add(2)

print(my_set)

d[x] = my_set

print(d)